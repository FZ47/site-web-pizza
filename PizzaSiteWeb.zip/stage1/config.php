<?php

   $db_name = "mysql:host=localhost;dbname=pizza_db";
   $username = "root";
   $password = '';

   $conn = new PDO($db_name, $username, $password);

?>