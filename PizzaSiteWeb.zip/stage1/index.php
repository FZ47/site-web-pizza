<?php

include 'config.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['register'])){

   $name = $_POST['nom'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass= !empty ($_POST['pass']) ? $_POST ['pass'] : NULL;
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass'] );
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `user` WHERE name = ? AND email = ?");
   $select_user->execute([$name, $email]);

   if($select_user->rowCount() > 0){
      $message[] = 'identifiant ou email existe déja !';
   }else{
      if($pass != $cpass){
         $message[] = 'le mot de passe ne correspond pas !';
      }else{
         $insert_user = $conn->prepare("INSERT INTO `user`(name, email, password) VALUES(?,?,?)");
         $insert_user->execute([$name, $email,$cpass]);
         $message[] = 'Inscription validée, maintenant connectez vous !';
      }
   }

}

if(isset($_POST['update_qty'])){
   $cart_id = $_POST['cart_id'];
   $qty = $_POST['qty'];
   $qty = filter_var($qty, FILTER_SANITIZE_STRING);
   $update_qty = $conn->prepare("UPDATE `cart` SET quantity = ? WHERE id = ?");
   $update_qty->execute([$qty, $cart_id]);
   $message[] = 'panier mise à jour !';
}

if(isset($_GET['delete_cart_item'])){
   $delete_cart_id = $_GET['delete_cart_item'];
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE id = ?");
   $delete_cart_item->execute([$delete_cart_id]);
   header('location:index.php');
}

if(isset($_GET['logout'])){
   session_unset();
   session_destroy();
   header('location:index.php');
}

if(isset($_POST['add_to_cart'])){

   if($user_id == ''){
      $message[] = 's il vous plait connectez vous en premier !';
   }else{

      $pid = $_POST['pid'];
      $name = $_POST['name'];
      $price = $_POST['price'];
      $image = $_POST['image'];
      $qty = $_POST['qty'];
      $qty = filter_var($qty, FILTER_SANITIZE_STRING);

      $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ? AND name = ?");
      $select_cart->execute([$user_id, $name]);

      if($select_cart->rowCount() > 0){
         $message[] = 'déja ajouté au panier';
      }else{
         $insert_cart = $conn->prepare("INSERT INTO `cart`(user_id, pid, name, price, quantity, image) VALUES(?,?,?,?,?,?)");
         $insert_cart->execute([$user_id, $pid, $name, $price, $qty, $image]);
         $message[] = 'ajouté au panier !';
      }

   }

}

if(isset($_POST['order'])){

   if($user_id == ''){
      $message[] = 'connectez vous en premier !';
   }else{
      $name = $_POST['name'];
      $name = filter_var($name, FILTER_SANITIZE_STRING);
      $number = $_POST['number'];
      $number = filter_var($number, FILTER_SANITIZE_STRING);
      $address = 'flat no.'.$_POST['flat'].', '.$_POST['street'].' - '.$_POST['pin_code'];
      $address = filter_var($address, FILTER_SANITIZE_STRING);
      $method = $_POST['method'];
      $method = filter_var($method, FILTER_SANITIZE_STRING);
      $total_price = $_POST['total_price'];
      $total_products = $_POST['total_products'];

      $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
      $select_cart->execute([$user_id]);

      if($select_cart->rowCount() > 0){
         $insert_order = $conn->prepare("INSERT INTO `orders`(user_id, name, number, method, address, total_products, total_price) VALUES(?,?,?,?,?,?,?)");
         $insert_order->execute([$user_id, $name, $number, $method, $address, $total_products, $total_price]);
         $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
         $delete_cart->execute([$user_id]);
         $message[] = 'commande passée avec succès !';
      }else{
         $message[] = 'votre panier est vide !';
      }
   }

}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>PIZZA YAD SiteWeb</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="css/style1.css">

</head>
<body>

<?php
   if(isset($message)){
      foreach($message as $message){
         echo '
         <div class="message">
            <span>'.$message.'</span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
         </div>
         ';
      }
   }
?>

<!-- header section début  -->

<header class="header">

   <section class="flex">

      <a href="#home" class="logo">PIZZA&nbsp;<i class="fas fa-pizza-slice"></i>&nbsp;YAD.</a>
      


      <nav class="navbar">
         <a href="#home">Acceuil</a>
         <a href="#about">A propos</a>
         <a href="#menu">Menu</a>
         <a href="#order">Panier</a>
         <a href="#faq">FAQ</a>
         <a href="#contact">Contact</a>
      </nav>

      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="user-btn" class="fas fa-user"></div>
         <div id="order-btn" class="fas fa-box"></div>
         <?php
            $count_cart_items = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
            $count_cart_items->execute([$user_id]);
            $total_cart_items = $count_cart_items->rowCount();
         ?>
         <div id="cart-btn" class="fas fa-shopping-cart"><span>(<?= $total_cart_items; ?>)</span></div>
      </div>

   </section>

</header>

<!-- header section debut -->

<div class="user-account">

   <section>

      <div id="close-account"><span>Fermer</span></div>

      <div class="user">
         <?php
            $select_user = $conn->prepare("SELECT * FROM `user` WHERE id = ?");
            $select_user->execute([$user_id]);
            if($select_user->rowCount() > 0){
               while($fetch_user = $select_user->fetch(PDO::FETCH_ASSOC)){
                  echo '<p>Bienvenu ! <span>'.$fetch_user['name'].'</span></p>';
                  echo '<a href="index.php?logout" class="btn">logout</a>';
               }
            }else{
               echo '<p><span>Vous n etes pas connectez !</span></p>';
            }
         ?>
      </div>

      <div class="display-orders">
         <?php
            $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
            $select_cart->execute([$user_id]);
            if($select_cart->rowCount() > 0){
               while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
                  echo '<p>'.$fetch_cart['name'].' <span>('.$fetch_cart['price'].' x '.$fetch_cart['quantity'].')</span></p>';
               }
            }else{
               echo '<p><span>Votre panier est vide !</span></p>';
            }
         ?>
      </div>

      <div class="flex">

         <form action="user_login.php" method="post">
            <h3>Connectez vous</h3>
            <input type="email" name="email" required class="box" placeholder="entrer votre email" maxlength="50">
            <input type="password" name="mot de passe" required class="box" placeholder="entrer votre mot de passe" maxlength="20">
            <input type="submit" value="connectez vous" name="login" class="btn">
         </form>

         <form action="" method="post">
            <h3>Inscrivez vous</h3>
            <input type="text" name="nom" oninput="this.value = this.value.replace(/\s/g, '')" required class="box" placeholder="entrer votre identifiant" maxlength="20">
            <input type="email" name="email" required class="box" placeholder="entrer votre email" maxlength="50">
            <input type="password" name="mot de passe" required class="box" placeholder="entrer votre mot de passe" maxlength="20" oninput="this.value = this.value.replace(/\s/g, '')">
            <input type="password" name="cpass" required class="box" placeholder="confirmer votre mot de passe" maxlength="20" oninput="this.value = this.value.replace(/\s/g, '')">
            <input type="submit" value="Inscrivez vous" name="Inscription" class="btn">
         </form>

      </div>

   </section>

</div>

<div class="my-orders">

   <section>

      <div id="close-orders"><span>Fermer</span></div>

      <h3 class="title"> Ma commande </h3>

      <?php
         $select_orders = $conn->prepare("SELECT * FROM `orders` WHERE user_id = ?");
         $select_orders->execute([$user_id]);
         if($select_orders->rowCount() > 0){
            while($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)){   
      ?>
      <div class="box">
         <p> placé sur : <span><?= $fetch_orders['placed_on']; ?></span> </p>
         <p> nom : <span><?= $fetch_orders['name']; ?></span> </p>
         <p> numéro : <span><?= $fetch_orders['number']; ?></span> </p>
         <p> addresse : <span><?= $fetch_orders['address']; ?></span> </p>
         <p> Methode de paiment : <span><?= $fetch_orders['method']; ?></span> </p>
         <p> total_orders : <span><?= $fetch_orders['total_products']; ?></span> </p>
         <p> prix total : <span>$<?= $fetch_orders['total_price']; ?>/-</span> </p>
         <p> status du paiement : <span style="color:<?php if($fetch_orders['payment_status'] == 'pending'){ echo 'red'; }else{ echo 'green'; }; ?>"><?= $fetch_orders['payment_status']; ?></span> </p>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">Rien n a été commandé !</p>';
      }
      ?>

   </section>

</div>

<div class="shopping-cart">

   <section>

      <div id="close-cart"><span>Fermer</span></div>

      <?php
         $grand_total = 0;
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
              $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']);
              $grand_total += $sub_total; 
      ?>
      <div class="box">
         <a href="index.php?delete_cart_item=<?= $fetch_cart['id']; ?>" class="fas fa-times" onclick="return confirm('supprimer cet article du panier ?');"></a>
         <img src="uploaded_img/<?= $fetch_cart['image']; ?>" alt="">
         <div class="content">
          <p> <?= $fetch_cart['name']; ?> <span>(<?= $fetch_cart['price']; ?> x <?= $fetch_cart['quantity']; ?>)</span></p>
          <form action="" method="post">
             <input type="hidden" name="cart_id" value="<?= $fetch_cart['id']; ?>">
             <input type="number" name="qty" class="qty" min="1" max="99" value="<?= $fetch_cart['quantity']; ?>" onkeypress="if(this.value.length == 2) return false;">
               <button type="submit" class="fas fa-edit" name="update_qty"></button>
          </form>
         </div>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty"><span>votre panier est vide !</span></p>';
      }
      ?>

      <div class="cart-total"> total : <span>$<?= $grand_total; ?>/-</span></div>

      <a href="#order" class="btn">commander maintenant</a>

   </section>

</div>

<div class="home-bg">

   <section class="home" id="home">

      <div class="slide-container">

         <div class="slide active">
            <div class="image">
               <img src="images/home-img-1.png" alt="">
            </div>
            <div class="content">
               <h3>Pizza base sauce tomate</h3>
               <div class="fas fa-angle-left" onclick="prev()"></div>
               <div class="fas fa-angle-right" onclick="next()"></div>
            </div>
         </div>

         <div class="slide">
            <div class="image">
               <img src="images/home-img-2.png" alt="">
            </div>
            <div class="content">
               <h3>Pizza base crème fraiche</h3>
               <div class="fas fa-angle-left" onclick="prev()"></div>
               <div class="fas fa-angle-right" onclick="next()"></div>
            </div>
         </div>

      </div>

   </section>

</div>

<!-- a propos section debut  -->

<section class="about" id="about">

   <h1 class="heading">A propos</h1>

   <div class="box-container">

   <div class="box">
         <img src="images/about-1.svg" alt="">
         <h3>Dégustation sur place</h3>
         <p>Profitez seul ou en famille d'un grand espace convivial en intérieur ou en terrasse !</p>
         <a href="#menu" class="btn">notre menu</a>
      </div>

      <div class="box">
         <img src="images/about-2.svg" alt="">
         <h3>Livraison 30 minutes</h3>
         <p>Profitez de notre service de Livraison rapide !</p>
         <a href="#menu" class="btn">notre menu</a>
      </div>

      <div class="box">
         <img src="images/about-3.svg" alt="">
         <h3>Partagez avec vos amis ou en famille</h3>
         <p>Profitez de nos différents offres tout au long de l'année avec des menus double ou familial !</p>
         <a href="#menu" class="btn">notre menu</a>
      </div>

   </div>

</section>

<!-- a propos section fin -->

<!-- menu section debut  -->

<section id="menu" class="menu">

   <h1 class="heading">Notre menu</h1>

   <div class="box-container">
   <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-1.jpg" alt="">
         <div class="name">Orientale</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-2.jpg" alt="">
         <div class="name">Fruits de mers</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-3.jpg" alt="">
         <div class="name">La Chicken</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-4.jpg" alt="">
         <div class="name">La Boursin</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-5.jpg" alt="">
         <div class="name">Tartiflette</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-6.jpg" alt="">
         <div class="name">La Fermière</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-7.jpg" alt="">
         <div class="name">Indienne</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-8.jpg" alt="">
         <div class="name">Kebab</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-9.jpg" alt="">
         <div class="name">La Venesia</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>
      <div class="box">
         <div class="price">€<span>13</span>/-</div>
         <img src="images/pizza-9.jpg" alt="">
         <div class="name">La Chèvre-Miel</div>
         <form action="" method="post">
            <input type="number" min="1" max="100" value="1" class="qty" name="qty">
            <input type="submit" value="ajouté au panier" name="add_to_cart" class="btn">
         </form>
      </div>

      <?php
         $select_products = $conn->prepare("SELECT * FROM `products`");
         $select_products->execute();
         if($select_products->rowCount() > 0){
            while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){    
      ?>
      <div class="box">
         <div class="price">$<?= $fetch_products['price'] ?>/-</div>
         <img src="uploaded_img/<?= $fetch_products['image'] ?>" alt="">
         <div class="name"><?= $fetch_products['name'] ?></div>
         <form action="" method="post">
            <input type="hidden" name="pid" value="<?= $fetch_products['id'] ?>">
            <input type="hidden" name="name" value="<?= $fetch_products['name'] ?>">
            <input type="hidden" name="price" value="<?= $fetch_products['price'] ?>">
            <input type="hidden" name="image" value="<?= $fetch_products['image'] ?>">
            <input type="number" name="qty" class="qty" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1">
            <input type="submit" class="btn" name="ajouté_au_panier" value="ajouté au panier">
         </form>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">aucun produit ajouté !</p>';
      }
      ?>

   </div>

</section>

<!-- menu section fin -->

<!-- commande section début  -->

<section class="order" id="order">

   <h1 class="heading">commander maintenant</h1>

   <form action="" method="post">

   <div class="display-orders">

   <?php
         $grand_total = 0;
         $cart_item[] = '';
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
              $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']);
              $grand_total += $sub_total; 
              $cart_item[] = $fetch_cart['name'].' ( '.$fetch_cart['price'].' x '.$fetch_cart['quantity'].' ) - ';
              $total_products = implode($cart_item);
              echo '<p>'.$fetch_cart['name'].' <span>('.$fetch_cart['price'].' x '.$fetch_cart['quantity'].')</span></p>';
            }
         }else{
            echo '<p class="empty"><span>votre panier est vide !</span></p>';
         }
      ?>

   </div>

      <div class="grand-total"> total : <span>$<?= $grand_total; ?>/-</span></div>
      
      
      <input type="hidden" name="total_price" value="<?= $grand_total; ?>">

      <div class="flex">
         <div class="inputBox">
            <span>votre nom :</span>
            <input type="text" name="name" class="box" required placeholder="entrer votre nom" maxlength="20">
         </div>
         <div class="inputBox">
            <span>votre numéro :</span>
            <input type="number" name="number" class="box" required placeholder="entrer votre numéro" min="0" max="9999999999" onkeypress="if(this.value.length == 10) return false;">
         </div>
         <div class="inputBox">
            <span>Méthode de paiement</span>
            <select name="method" class="box">
            <option value="cash">Paiement en ligne</option>
               <option value="cash">Paiement en espèce lors de la livraison</option>
               <option value="cart credit">Carte de crédit</option>
               <option value="paypal">PayPal</option>
            </select>
         </div>
         <div class="inputBox">
            <span>Adresse :</span>
            <input type="text" name="flat" class="box" required placeholder="" maxlength="50">
         </div>
         <div class="inputBox">
            <span>Code postale :</span>
            <input type="number" name="ville" class="box" required placeholder="" maxlength="50">
         </div>
         <div class="inputBox">
            <span>Adresse complémentaire :</span>
            <input type="text" name="ville" class="box" required placeholder="" maxlength="50">
         </div>
         <div class="inputBox">
            <span>code pin :</span>
            <input type="password" name="pin_code" class="box" required placeholder="" min="0" maxlength="4" pattern="[0-9]{4}" onkeypress="if(this.value.length == 6) return false;">
         </div>
      </div>

      <input type="submit" value="commander maintenant" class="btn" name="order">

   </form>

</section>

<!-- commande section fin -->

<!-- faq section début  -->

<section class="faq" id="faq">

   <h1 class="heading">FAQ</h1>

   <div class="accordion-container">

   <div class="accordion">
         <div class="accordion-heading">
            <span>Quels sont les horaires auxquels je peux commander ?</span>
            <i class="fas fa-angle-down"></i>
         </div>
         <p class="accrodion-content">
            Les horaires de commande correspondent aux horaires d’ouverture et de fermeture de votre restaurant.
         </p>
      </div>

      <div class="accordion">
         <div class="accordion-heading">
            <span>Puis-je encore modifier ma commande une fois celle-ci validée ?</span>
            <i class="fas fa-angle-down"></i>
         </div>
         <p class="accrodion-content">
         Une fois validée, votre commande n’est plus modifiable ou annulable.
      </p>
      </div>

      <div class="accordion">
         <div class="accordion-heading">
            <span>J’ai un problème avec ma commande, que faire ?</span>
            <i class="fas fa-angle-down"></i>
         </div>
         <p class="accrodion-content">
         En cas de souci avec votre commande, nous vous invitons à joindre le : 09.88.49.57.26 ou bien par email : pizzayad01@gmail.com</p>
      </div>

      <div class="accordion">
         <div class="accordion-heading">
            <span>Quel(s) justificatif(s) dois-je montrer en restaurant pour récupérer ma commande ?</span>
            <i class="fas fa-angle-down"></i>
         </div>
         <p class="accrodion-content">
            Lors du retrait de votre commande, présentez votre email de confirmation de commande (sur mobile ou en version papier) et scannez le QR CODE ou communiquez votre numéro de retrait au serveur.
         </p>
      </div>


      <div class="accordion">
         <div class="accordion-heading">
            <span>Y-a-t-il un montant minimum de commande ?</span>
            <i class="fas fa-angle-down"></i>
         </div>
         <p class="accrodion-content">
            Non.
         </p>
      </div>
      <div class="accordion">
         <div class="accordion-heading">
            <span>Existe t-il différente taille pour les pizzas ?</span>
            <i class="fas fa-angle-down"></i>
         </div>
         <p class="accrodion-content">
            Oui, il existe 3 tailles : la petite pour 8$, la moyenne pour 12$ et la grande pour 17$.
         </p>
      </div>

   </div>

</section>

<!-- faq section fin-->

<!-- footer section début  -->

<section class="footer">

   <div class="box-container">

   <div class="box">
         <i class="fas fa-phone"></i>
         <h3>Téléphone</h3>
         <p>09 88 49 57 26</p>
      </div>


      <div class="box">
         <i class="fas fa-map-marker-alt"></i>
         <h3>Adresse</h3>
         <p>40 BIS Boulevard Eugène Pelletan - 47000 Agen</p>
      </div>

      <div class="box">
         <i class="fas fa-clock"></i>
         <h3>Horaire D'ouverture</h3>
         <p>Du Lun au Dimanche de 11h à 14h et de 18h à 23h</p>
      </div>

      <div class="box">
         <i class="fas fa-envelope"></i>
         <h3>Adresse Mail</h3>
         <p>pizzayad01@gmail.com</p>
      </div>
   </div>

   <div class="map">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11441.175172300864!2d0.6169852927249585!3d44.20101515036482!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12abb31a2d814e3f%3A0x6659e4bc918094d9!2s40%20Bd%20Eug%C3%A8ne%20Pelletan%2C%2047000%20Agen!5e0!3m2!1sfr!2sfr!4v1655814813713!5m2!1sfr!2sfr"
          width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
  </div>

   <div class="credit">
      &copy; copyright @ <?= date('Y'); ?> by <span>Fayçal Z</span> | Tous droit réservé !
   </div>
   <div class="social">
                <i class="fab fa-facebook"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-pinterest"></i>
                <i class="fab fa-twitter"></i>

            </div>

</section>

<script src="js/script.js"></script>

</body>
</html>